package sample;

public interface Postman {
	
	void deliverMessage(String msg);
}
